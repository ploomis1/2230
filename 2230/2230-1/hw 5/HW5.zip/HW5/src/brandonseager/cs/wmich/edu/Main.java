package brandonseager.cs.wmich.edu;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) throws FileNotFoundException {
		readFile();
		//test();
//		tree.addNode(data);
//		System.out.println(tree.search(tree, data));
//		
//		tree.remove(tree, data);
//		System.out.println(tree.toString());
//	
	
	}	
	public static void test(){//testing stuff here its all bullshit
		String bullshit = "tittymilk";
		String bull = "mesohorny";
		BST<String> bitch = new BST<String>();
		bitch.insert(bullshit);
		bitch.insert(" ");
		bitch.insert(bull);
		//System.out.println(bitch);
		bitch.delete(bullshit);
		bitch.preOrderTraversal();
		bitch.inOrderTraversal();
		
	}
	
	
	
	public static void readFile() throws FileNotFoundException{
		
		//BinarySearchTree tree = new BinarySearchTree();
		BST<String> bst = new BST<String>();
		@SuppressWarnings("resource")
		Scanner fileScanner = new Scanner(new File("hw5cs3310F16data.txt"));//needed to add the file scanner
		System.out.println("Here is what is happening to the search tree:");
		
		while (fileScanner.hasNext()){
			String todo = fileScanner.next();
			System.out.println(todo);//stored in todo might need this later
			//System.out.println();
			if(todo.equals("Insert:")){
				String add = fileScanner.nextLine();
				System.out.println("adding"+add);//this i will keep seen by user
				String[] parts = add.split(",");
				//System.out.println(parts[0]);//need to get rid of this
				bst.insert(parts[0]);
				//break;
			}
			else if(todo.equals("Delete:")){
				String delete = fileScanner.nextLine();
				System.out.println("deleteing"+delete);//this i will keep seen by user
				bst.delete(delete);
				//break;
			}
			else if(todo.equals("Inorder")){
				bst.inOrderTraversal();
				System.out.println();
			}
			else if(todo.equals("Preorder")){
				bst.preOrderTraversal();
				System.out.println();
			}
			else if(todo.equals("Postorder")){
				//System.out.println();
				bst.preOrderTraversal(); //I need to make a postorder method
				System.out.println();
			}
			else if(todo.equals("Search:")){//search should work once stuff is added
				String searchThis = fileScanner.nextLine();
				System.out.println("We are searching for:"+searchThis);
				System.out.println("If found it will be True, otherwise false");
				System.out.println(bst.search(searchThis));//this should be done
			}	
		}
		System.out.println();
		System.out.println("Here is the Tree so far:");
		System.out.println(bst.toString());
	}
}
